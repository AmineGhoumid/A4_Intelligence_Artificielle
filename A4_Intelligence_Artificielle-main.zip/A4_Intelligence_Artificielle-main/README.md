# A4_Intelligence_Artificielle

https://moodle-ingenieurs.cesi.fr/pluginfile.php/370229/mod_resource/content/3/co/Projet.html
